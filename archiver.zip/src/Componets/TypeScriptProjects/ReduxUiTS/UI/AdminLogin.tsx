import React from 'react';

const AdminLogin = () => {
  return <>jao</>;
};

export default AdminLogin;
