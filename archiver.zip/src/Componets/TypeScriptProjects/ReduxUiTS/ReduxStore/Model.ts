export default interface Model {
  id: string;
  userName: string;
  BikeName: string;
  BikeNo: string;
  MissingDate: string;
  MobileNo: number;
  MissingPlace: string;
}
