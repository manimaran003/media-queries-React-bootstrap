export default interface DataModel {
  id: string;
  username: string;
  members: string;
  eventName: string;
  time: string;
}
