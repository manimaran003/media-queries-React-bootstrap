export const data = [
  {
    id: 1,
    url: 'https://5.imimg.com/data5/SELLER/Default/2021/2/IX/BZ/CP/79732592/nestle-dairy-whitener-milk-powder-2--500x500.jpg',
    ProductName: 'Milk powder',
    ProductPrice: 180
  },
  {
    id: 2,
    url: 'https://n2.sdlcdn.com/imgs/j/l/7/KERALA-NATURAL-SPICES-Almond-Badam-SDL712676234-1-21ee5.jpg',
    ProductName: 'Badham Nuts',
    ProductPrice: 200
  },
  {
    id: 3,
    url: 'https://5.imimg.com/data5/KP/AF/EK/SELLER-58383242/herbal-shampoo-with-panchtatva-galway-rupabham-500x500.jpg',
    ProductName: 'SunSilk',
    ProductPrice: 180
  },
  {
    id: 4,
    url: 'https://www.debakigrocery.com/wp-content/uploads/2020/07/Gold-Winner-1lit.jpg',
    ProductName: 'gold winner',
    ProductPrice: 300
  },
  {
    id: 5,
    url: 'https://sonikatravels.files.wordpress.com/2020/12/parachute1.jpg?w=1024',
    ProductName: 'parachute',
    ProductPrice: 140
  },
  {
    id: 6,
    url: 'https://post.healthline.com/wp-content/uploads/2020/12/Lundberg-Family-Farms-Organic-Long-Grain-Rice.png',
    ProductName: 'Basmathi',
    ProductPrice: 500
  },
  {
    id: 7,
    url: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRp8JNKmHEQySk101pI3CTzlE3cB6zBn5s_dpk38zSluD8JZ5puJckR5lniZnwzysAZXj8&usqp=CAU',
    ProductName: 'Coffee Powder',
    ProductPrice: 239
  },
  {
    id: 8,
    url: 'https://www.luluhypermarket.in/medias/49969-0001.jpg-1200Wx1200H?context=bWFzdGVyfGltYWdlc3wxNTY0ODl8aW1hZ2UvanBlZ3xoZmUvaGEzLzg5NDM0MjQ2MzQ5MTAvNDk5NjktMDAwMS5qcGdfMTIwMFd4MTIwMEh8YTg5OGJlZjU5ZjNjZWY0MTFjNTc1N2NlOTY1OGZmMGIyNDViMmRiNDc2YWY2MjQ0NGVmYjlkZmEwZTY3MDhiNw',
    ProductName: 'East Tea',
    ProductPrice: 567
  },
  {
    id: 9,
    url: 'https://5.imimg.com/data5/ER/HE/SQ/SELLER-30546292/mango-juice-300ml-500x500.jpg',
    ProductName: 'Mazza',
    ProductPrice: 45
  },
  {
    id: 10,
    url: 'https://5.imimg.com/data5/ZK/NE/CB/SELLER-59097240/1-5l-sprite-cold-drink-500x500.jpg',
    ProductName: 'sprite',
    ProductPrice: 100
  },
  {
    id: 11,
    url: 'https://m.media-amazon.com/images/I/517reIu-eXL._SX679_.jpg',
    ProductName: 'cococola',
    ProductPrice: 380
  },
  {
    id: 12,
    url: 'https://m.media-amazon.com/images/I/517reIu-eXL._SX679_.jpg',
    ProductName: 'cococola',
    ProductPrice: 80
  },
  {
    id: 13,
    url: 'https://5.imimg.com/data5/ZK/NE/CB/SELLER-59097240/1-5l-sprite-cold-drink-500x500.jpg',
    ProductName: 'sprite',
    ProductPrice: 80
  },
  {
    id: 14,
    url: 'https://images.immediate.co.uk/production/volatile/sites/30/2017/01/Bananas-218094b-scaled.jpg?quality=45&resize=768,574',
    ProductName: 'bannana',
    ProductPrice: 90
  },
  {
    id: 15,
    url: 'https://5.imimg.com/data5/EE/ER/MY-27568370/fresh-orange-500x500.png',
    ProductName: 'orange',
    ProductPrice: 200
  },
  {
    id: 16,
    url: 'https://images.immediate.co.uk/production/volatile/sites/30/2020/02/pumpkin-3f3d894.jpg?quality=90&resize=661%2C600',
    ProductName: 'pumpkin',
    ProductPrice: 380
  },
  {
    id: 17,
    url: 'https://m.media-amazon.com/images/I/41P8zMQqR7L._SX466_.jpg',
    ProductName: 'grapes',
    ProductPrice: 980
  },
  {
    id: 18,
    url: 'https://www.bigbasket.com/media/uploads/p/xxl/20001428_2-fresho-grapes-green-with-seed.jpg',
    ProductName: 'green grapes',
    ProductPrice: 400
  },
  {
    id: 19,
    url: 'https://getezi.com/image/cache/catalog/productimage/a-papaya-cut-in-half-550x550w.jpg',
    ProductName: 'papaya',
    ProductPrice: 980
  },
  {
    id: 20,
    url: 'https://5.imimg.com/data5/ZK/NE/CB/SELLER-59097240/1-5l-sprite-cold-drink-500x500.jpg',
    ProductName: 'sprite',
    ProductPrice: 80
  },
  {
    id: 21,
    url: 'https://www.indbazaar.com/pub/media/catalog/product/cache/b040d94160a0ba8095713fea5e718ad4/p/d/pdy90007.jpg',
    ProductName: 'bovonto',
    ProductPrice: 900
  },
  {
    id: 22,
    url: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ3OuDCNYlYD-GAuFnSoz-XqyRlpHzoLzX_8w&usqp=CAU',
    ProductName: 'c2 drink',
    ProductPrice: 20
  },
  {
    id: 23,
    url: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRkFz78B6ix7mgM10ddjZUHMcYUmK7QNfk8kNTnD5T7z5h8OjE8SdtbPPDPBWV8jypPWR8&usqp=CAU',
    ProductName: 'phoric',
    ProductPrice: 320
  },
  {
    id: 24,
    url: 'https://www.bigbasket.com/media/uploads/p/xxl/40195155_2-mountain-dew-soft-drink.jpg',
    ProductName: 'Mountain Dew',
    ProductPrice: 300
  },
  {
    id: 26,
    url: 'https://www.herbaldaily.in/Uploads/Products/88f08402-0aac-4cbe-af04-6c65ba2f5b36/5f75ea12-2dea-48dc-aa4d-496605e9c9a6/_large.jpg',
    ProductName: 'herbal oil',
    ProductPrice: 80
  },
  {
    id: 27,
    url: 'https://5.imimg.com/data5/ZF/IA/MP/SELLER-13176868/2-liter-limca-soft-drink-500x500.jpg',
    ProductName: 'limca',
    ProductPrice: 70
  },
  {
    id: 28,
    url: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTmsLEUeVA4UQLXAEFgVwHl9SzornIe3MqNQ&usqp=CAU',
    ProductName: 'Rubica',
    ProductPrice: 790
  },
  {
    id: 29,
    url: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQdW6M4WzgOmCo8u2jnSfZdaBajopHOYTz6DA&usqp=CAU',
    ProductName: 'pepsi',
    ProductPrice: 760
  },
  {
    id: 30,
    url: 'https://malayalis.co.in/images/pro/White-Lemon-softdrink.png',
    ProductName: 'malayalisl',
    ProductPrice: 980
  },
  {
    id: 31,
    url: 'https://www.herbaldaily.in/Uploads/Products/88f08402-0aac-4cbe-af04-6c65ba2f5b36/5f75ea12-2dea-48dc-aa4d-496605e9c9a6/_large.jpg',
    ProductName: 'herbal oil',
    ProductPrice: 80
  }
];
