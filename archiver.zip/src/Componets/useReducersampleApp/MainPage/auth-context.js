import React from 'react';

const AuthContext = React.createContext({
  products: []
});

export default AuthContext;
