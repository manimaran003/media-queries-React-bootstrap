export const enum ActionTypes {
  GETtrain = 'GETtrain',
  newTrain = 'newTrain',
  DELSuccess = 'DELSuccess',
  AddSuccess = 'ADDSuccess',
  userTrain = 'userTrain',
  EditUser = 'EditUser',
  getError = 'getError',
  GETAPI = 'GETAPI',
  POSTAPI = 'POSTAPI',
  PUTAPI = 'PUTAPI',
  DELETE = 'DELETEAPI'
}
