export default interface ConvertTsModel {
  id: string;
  from: string;
  time: string;
  arrival: string;
  passengerName: string;
  trainName: string;
  passengerAge: string;
  to: string;
  trainNumber: string;
}
