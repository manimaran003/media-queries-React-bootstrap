
export default interface data {
  id: string;
  from: string;
  to: string;
  arrival: string;
  time: string;
  trainName: string;
  trainNumber: string;
}
export default interface ConvertTsGet {
  id: string;
  from: string;
  to: string;
  arrival: string;
  time: string;
  trainName: string;
  trainNumber: string;
}
export default interface trip{
  id: string;
  from: string;
  to: string;
  arrival: string;
  time: string;
  trainName: string;
  trainNumber: string;
}
export default interface details{
  PostReducer: data;
  trips:data;
  error:string;
}
